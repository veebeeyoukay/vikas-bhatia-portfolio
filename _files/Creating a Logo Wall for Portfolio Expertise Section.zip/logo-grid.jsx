import { useState } from "react"

export function LogoGrid({ logos }) {
  const [hoveredLogo, setHoveredLogo] = useState(null)

  return (
    <div className="w-full max-w-6xl mx-auto">
      <div className="grid grid-cols-3 md:grid-cols-5 lg:grid-cols-6 gap-6 md:gap-8">
        {logos.map((logo, index) => (
          <div
            key={logo.name}
            className="group relative flex items-center justify-center p-4 bg-white dark:bg-gray-800 rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 transform hover:scale-105 hover:-translate-y-1"
            style={{
              animationDelay: `${index * 100}ms`,
            }}
            onMouseEnter={() => setHoveredLogo(logo.name)}
            onMouseLeave={() => setHoveredLogo(null)}
          >
            <div className="relative w-full h-16 flex items-center justify-center">
              <img
                src={logo.src}
                alt={logo.alt}
                className="max-w-full max-h-full object-contain filter group-hover:brightness-110 transition-all duration-300"
                style={{
                  filter: hoveredLogo === logo.name ? 'drop-shadow(0 4px 8px rgba(0,0,0,0.2))' : 'none'
                }}
              />
            </div>
            
            {/* Tooltip */}
            <div className="absolute -top-12 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none whitespace-nowrap z-10">
              {logo.alt}
            </div>
          </div>
        ))}
      </div>
      
      {/* Floating animation styles */}
      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
        
        .group:nth-child(odd) {
          animation: float 6s ease-in-out infinite;
        }
        
        .group:nth-child(even) {
          animation: float 6s ease-in-out infinite reverse;
        }
      `}</style>
    </div>
  )
}

