# Portfolio Logo Wall - Vikas Bhatia

A professional, interactive logo wall showcasing companies and organizations you've worked with throughout your career. This React-based component features a responsive grid layout with hover effects, dark/light theme support, and smooth animations.

## 🌟 Features

- **Responsive Design**: Adapts beautifully to desktop, tablet, and mobile devices
- **Dark/Light Theme**: Toggle between themes with smooth transitions
- **Interactive Hover Effects**: Logos scale and show tooltips on hover
- **Professional Layout**: Clean, modern design perfect for portfolio websites
- **High-Quality Logos**: Curated collection of company logos in optimal formats
- **Smooth Animations**: Subtle floating animations and transitions
- **Accessibility**: Proper alt text and keyboard navigation support

## 🏢 Featured Companies

### Financial Services
- BlackRock
- Federal Reserve
- American Express
- VISA
- Blackstone

### Technology & Cloud
- Microsoft
- Amazon Web Services (AWS)
- Google Cloud
- HP
- Deloitte

### Enterprise & Media
- Target Corporation
- Shell Oil
- BBC
- Capgemini

## 🚀 Quick Start

### Development
```bash
cd portfolio-logo-wall
pnpm install
pnpm run dev
```

### Production Build
```bash
pnpm run build
```

The built files will be in the `dist/` directory, ready for deployment.

## 📁 Project Structure

```
portfolio-logo-wall/
├── src/
│   ├── assets/           # Company logos
│   ├── components/
│   │   ├── ui/
│   │   │   └── logo-grid.jsx      # Main logo grid component
│   │   └── theme-provider.jsx     # Theme management
│   ├── App.jsx          # Main application
│   └── main.jsx         # Entry point
├── dist/                # Production build
└── package.json         # Dependencies
```

## 🎨 Customization

### Adding New Logos
1. Add logo files to `src/assets/`
2. Import in `App.jsx`
3. Add to the `companyLogos` array

### Styling
- Modify `src/components/ui/logo-grid.jsx` for grid layout
- Update `src/App.css` for global styles
- Tailwind CSS classes for quick styling changes

### Theme Colors
The component uses CSS custom properties for theming:
- Light theme: Clean whites and subtle grays
- Dark theme: Rich blacks with accent highlights

## 🔧 Integration

### For Existing React Projects
1. Copy the `src/components/ui/logo-grid.jsx` component
2. Copy the logo assets
3. Import and use the `LogoGrid` component

### For Other Frameworks
The built `dist/` folder contains static files that can be:
- Hosted on any web server
- Integrated into existing websites
- Used as a standalone page

## 📱 Responsive Breakpoints

- Mobile: 3 columns
- Tablet: 5 columns  
- Desktop: 6 columns

## 🎯 Performance

- Optimized images with proper compression
- Lazy loading for better performance
- Minimal bundle size with tree shaking
- CSS-in-JS for component-scoped styles

## 🌐 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## 📄 License

This project is created for Vikas Bhatia's portfolio. Company logos are property of their respective owners.

---

**Built with React, Vite, Tailwind CSS, and shadcn/ui**

