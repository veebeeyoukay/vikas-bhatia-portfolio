import { useState, useEffect } from 'react'
import { LogoGrid } from '@/components/ui/logo-grid.jsx'
import { ThemeProvider, useTheme } from '@/components/theme-provider.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Moon, Sun, Users, Award, Building2 } from 'lucide-react'
import './App.css'

// Import logo assets
import blackrockLogo from './assets/blackrock.jpg'
import federalReserveLogo from './assets/federal_reserve.png'
import deloitteLogo from './assets/deloitte.png'
import targetLogo from './assets/target.jpg'
import americanExpressLogo from './assets/american_express.png'
import blackstoneLogo from './assets/blackstone.png'
import visaLogo from './assets/visa.png'
import shellLogo from './assets/shell.png'
import hpLogo from './assets/hp.png'
import microsoftLogo from './assets/microsoft.jpg'
import awsLogo from './assets/aws.png'
import googleCloudLogo from './assets/google_cloud.png'
import azureLogo from './assets/azure.png'
import bbcLogo from './assets/bbc.png'
import capgeminiLogo from './assets/capgemini.png'

const companyLogos = [
  { src: blackrockLogo, alt: "BlackRock", name: "blackrock" },
  { src: federalReserveLogo, alt: "Federal Reserve", name: "federal_reserve" },
  { src: deloitteLogo, alt: "Deloitte", name: "deloitte" },
  { src: targetLogo, alt: "Target Corporation", name: "target" },
  { src: americanExpressLogo, alt: "American Express", name: "american_express" },
  { src: blackstoneLogo, alt: "Blackstone", name: "blackstone" },
  { src: visaLogo, alt: "VISA", name: "visa" },
  { src: shellLogo, alt: "Shell Oil", name: "shell" },
  { src: hpLogo, alt: "HP", name: "hp" },
  { src: microsoftLogo, alt: "Microsoft", name: "microsoft" },
  { src: awsLogo, alt: "Amazon Web Services", name: "aws" },
  { src: googleCloudLogo, alt: "Google Cloud", name: "google_cloud" },
  { src: azureLogo, alt: "Microsoft Azure", name: "azure" },
  { src: bbcLogo, alt: "BBC", name: "bbc" },
  { src: capgeminiLogo, alt: "Capgemini", name: "capgemini" },
]

function ThemeToggle() {
  const { theme, setTheme } = useTheme()

  return (
    <Button
      variant="outline"
      size="icon"
      onClick={() => setTheme(theme === "light" ? "dark" : "light")}
      className="fixed top-4 right-4 z-50"
    >
      <Sun className="h-[1.2rem] w-[1.2rem] rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
      <Moon className="absolute h-[1.2rem] w-[1.2rem] rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
      <span className="sr-only">Toggle theme</span>
    </Button>
  )
}

function AppContent() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse text-foreground">Loading...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
      <ThemeToggle />
      
      {/* Hero Section */}
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-6">
            <Award className="w-4 h-4" />
            Professional Experience
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent mb-6">
            Trusted by Industry Leaders
          </h1>
          
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
            Over 15+ years of cybersecurity and risk management expertise, 
            delivering innovative solutions to Fortune 500 companies and government agencies.
          </p>
          
          <div className="flex items-center justify-center gap-8 text-sm text-muted-foreground mb-12">
            <div className="flex items-center gap-2">
              <Building2 className="w-4 h-4" />
              <span>130+ Companies Served</span>
            </div>
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              <span>15+ Years Experience</span>
            </div>
            <div className="flex items-center gap-2">
              <Award className="w-4 h-4" />
              <span>Multiple Certifications</span>
            </div>
          </div>
        </div>

        {/* Logo Cloud Section */}
        <div className="flex flex-col items-center">
          <h2 className="text-2xl font-semibold text-center mb-8 text-foreground">
            Companies I've Worked With
          </h2>
          
          <div className="w-full">
            <LogoGrid logos={companyLogos} />
          </div>
          
          <p className="text-center text-muted-foreground mt-8 max-w-2xl">
            From financial institutions to technology giants, I've helped organizations 
            strengthen their cybersecurity posture and achieve compliance across various industries.
          </p>
        </div>

        {/* Additional Info */}
        <div className="mt-16 text-center">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="p-6 rounded-lg bg-card border">
              <h3 className="font-semibold text-lg mb-2">Financial Services</h3>
              <p className="text-muted-foreground text-sm">
                BlackRock, Federal Reserve, American Express, VISA, Blackstone
              </p>
            </div>
            <div className="p-6 rounded-lg bg-card border">
              <h3 className="font-semibold text-lg mb-2">Technology & Cloud</h3>
              <p className="text-muted-foreground text-sm">
                Microsoft, AWS, Google Cloud, HP, Deloitte
              </p>
            </div>
            <div className="p-6 rounded-lg bg-card border">
              <h3 className="font-semibold text-lg mb-2">Enterprise & Media</h3>
              <p className="text-muted-foreground text-sm">
                Target, Shell, BBC, Capgemini, and many more
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function App() {
  return (
    <ThemeProvider defaultTheme="light" storageKey="portfolio-theme">
      <AppContent />
    </ThemeProvider>
  )
}

export default App

