"use client"

import { useEffect, useMemo, useState } from "react"
import { useTheme } from "next-themes"
import { Cloud } from "react-icon-cloud"

export const cloudProps = {
  containerProps: {
    style: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      width: "100%",
      paddingTop: 40,
    },
  },
  options: {
    reverse: true,
    depth: 1,
    wheelZoom: false,
    imageScale: 2,
    activeCursor: "default",
    tooltip: "native",
    initial: [0.1, -0.1],
    clickToFront: 500,
    tooltipDelay: 0,
    outlineColour: "#0000",
    maxSpeed: 0.04,
    minSpeed: 0.02,
  },
}

export const renderCustomLogo = (logoData, theme) => {
  const { src, alt, name } = logoData
  
  return (
    <div
      key={name}
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        width: "60px",
        height: "60px",
        borderRadius: "12px",
        backgroundColor: theme === "light" ? "#ffffff" : "#1a1a1a",
        boxShadow: theme === "light" 
          ? "0 2px 8px rgba(0,0,0,0.1)" 
          : "0 2px 8px rgba(255,255,255,0.1)",
        padding: "8px",
        transition: "all 0.3s ease",
        cursor: "pointer",
      }}
      title={alt}
      onMouseEnter={(e) => {
        e.target.style.transform = "scale(1.1)"
        e.target.style.boxShadow = theme === "light" 
          ? "0 4px 16px rgba(0,0,0,0.2)" 
          : "0 4px 16px rgba(255,255,255,0.2)"
      }}
      onMouseLeave={(e) => {
        e.target.style.transform = "scale(1)"
        e.target.style.boxShadow = theme === "light" 
          ? "0 2px 8px rgba(0,0,0,0.1)" 
          : "0 2px 8px rgba(255,255,255,0.1)"
      }}
    >
      <img
        src={src}
        alt={alt}
        style={{
          width: "100%",
          height: "100%",
          objectFit: "contain",
          filter: theme === "dark" ? "brightness(1.1)" : "none",
        }}
      />
    </div>
  )
}

export function LogoCloud({ logos }) {
  const [mounted, setMounted] = useState(false)
  const { theme } = useTheme()

  useEffect(() => {
    setMounted(true)
  }, [])

  const renderedLogos = useMemo(() => {
    if (!mounted || !logos) return null

    return logos.map((logo) =>
      renderCustomLogo(logo, theme || "light")
    )
  }, [logos, theme, mounted])

  if (!mounted) {
    return (
      <div className="relative flex size-full max-w-lg items-center justify-center overflow-hidden rounded-lg border bg-background px-20 pb-20 pt-8">
        <div className="animate-pulse">Loading...</div>
      </div>
    )
  }

  return (
    <div className="relative flex size-full max-w-lg items-center justify-center overflow-hidden rounded-lg border bg-background px-20 pb-20 pt-8">
      <Cloud {...cloudProps}>
        <>{renderedLogos}</>
      </Cloud>
    </div>
  )
}

