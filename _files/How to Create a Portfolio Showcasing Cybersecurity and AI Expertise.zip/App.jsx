import React, { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { 
  Shield, 
  Brain, 
  Rocket, 
  Users, 
  Award, 
  Mail, 
  Linkedin, 
  ExternalLink,
  ChevronDown,
  Menu,
  X,
  CheckCircle,
  TrendingUp,
  Lock,
  Zap,
  Globe,
  Target,
  Briefcase
} from 'lucide-react'
import './App.css'

// Import assets
import professionalPortrait1 from './assets/professional_portrait_1.jpg'
import professionalPortrait2 from './assets/professional_portrait_2.jpg'
import cyberBackground1 from './assets/cyber_background_1.jpg'
import cyberBackground2 from './assets/cyber_background_2.jpg'
import aiBackground1 from './assets/ai_background_1.jpg'

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [activeSection, setActiveSection] = useState('hero')

  useEffect(() => {
    const handleScroll = () => {
      const sections = ['hero', 'about', 'expertise', 'experience', 'services', 'contact']
      const scrollPosition = window.scrollY + 100

      for (const section of sections) {
        const element = document.getElementById(section)
        if (element) {
          const { offsetTop, offsetHeight } = element
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section)
            break
          }
        }
      }
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
    setIsMenuOpen(false)
  }

  const navItems = [
    { id: 'hero', label: 'Home' },
    { id: 'about', label: 'About' },
    { id: 'expertise', label: 'Expertise' },
    { id: 'experience', label: 'Experience' },
    { id: 'services', label: 'Services' },
    { id: 'contact', label: 'Contact' }
  ]

  return (
    <div className="min-h-screen bg-warm-white text-deep-slate">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-warm-white/95 backdrop-blur-lg border-b border-warm-taupe/30">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="flex items-center justify-between h-16">
            <div className="font-sf-pro text-xl font-semibold text-deep-slate">
              Vikas Bhatia
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`text-sm font-medium transition-colors duration-200 hover:text-sage-green ${
                    activeSection === item.id ? 'text-copper' : 'text-deep-slate'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2 text-deep-slate hover:text-sage-green transition-colors"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden bg-warm-white border-t border-warm-taupe/30">
            <div className="px-6 py-4 space-y-3">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`block w-full text-left text-sm font-medium transition-colors duration-200 hover:text-sage-green ${
                    activeSection === item.id ? 'text-copper' : 'text-deep-slate'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="hero" className="pt-16 min-h-screen flex items-center">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 py-20">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8">
              <div className="space-y-6">
                <h1 className="text-5xl lg:text-6xl font-sf-pro font-bold text-deep-slate leading-tight">
                  AI-Cybersecurity
                  <span className="block text-sage-green">Executive</span>
                </h1>
                <p className="text-xl text-charcoal/80 leading-relaxed max-w-lg">
                  Bridging innovation and risk management. Transforming AI startups and enterprises 
                  through strategic cybersecurity leadership.
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  onClick={() => scrollToSection('contact')}
                  className="bg-sage-green hover:bg-sage-green/90 text-warm-white px-8 py-3 rounded-lg font-medium transition-all duration-200 hover:shadow-lg"
                >
                  Schedule Consultation
                </Button>
                <Button 
                  onClick={() => scrollToSection('expertise')}
                  variant="outline"
                  className="border-deep-slate text-deep-slate hover:bg-warm-taupe/20 px-8 py-3 rounded-lg font-medium transition-all duration-200"
                >
                  View Expertise
                </Button>
              </div>

              <div className="flex items-center space-x-8 pt-4">
                <div className="text-center">
                  <div className="text-2xl font-sf-pro font-bold text-copper">$750K</div>
                  <div className="text-sm text-charcoal/70">Raised for AI Startup</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-sf-pro font-bold text-copper">15+</div>
                  <div className="text-sm text-charcoal/70">Years Experience</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-sf-pro font-bold text-copper">TS/SCI</div>
                  <div className="text-sm text-charcoal/70">Security Clearance</div>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="relative z-10">
                <img
                  src={professionalPortrait1}
                  alt="Vikas Bhatia - AI-Cybersecurity Executive"
                  className="w-full max-w-md mx-auto rounded-2xl shadow-2xl"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-br from-sage-green/20 to-copper/20 rounded-2xl transform rotate-3 -z-10"></div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 bg-cream">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8">
              <div className="space-y-6">
                <h2 className="text-4xl font-sf-pro font-bold text-deep-slate">
                  Where Innovation Meets Security
                </h2>
                <p className="text-lg text-charcoal/80 leading-relaxed">
                  I bridge the gap between cutting-edge AI innovation and enterprise-grade security. 
                  With a unique combination of government clearance, startup experience, and Fortune 500 
                  expertise, I help organizations navigate the complex intersection of AI and cybersecurity.
                </p>
                <p className="text-lg text-charcoal/80 leading-relaxed">
                  From scaling my own AI-powered SaaS to $700K ARR to advising Fortune 500 CISOs on 
                  AI governance, I bring both strategic vision and hands-on execution to every engagement.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Shield className="w-5 h-5 text-sage-green" />
                    <span className="font-medium text-deep-slate">Security Leadership</span>
                  </div>
                  <p className="text-sm text-charcoal/70">15+ years protecting critical infrastructure</p>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Brain className="w-5 h-5 text-sage-green" />
                    <span className="font-medium text-deep-slate">AI Innovation</span>
                  </div>
                  <p className="text-sm text-charcoal/70">Built and scaled AI-powered solutions</p>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Rocket className="w-5 h-5 text-sage-green" />
                    <span className="font-medium text-deep-slate">Startup Success</span>
                  </div>
                  <p className="text-sm text-charcoal/70">$750K raised, $700K ARR achieved</p>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Globe className="w-5 h-5 text-sage-green" />
                    <span className="font-medium text-deep-slate">Global Impact</span>
                  </div>
                  <p className="text-sm text-charcoal/70">Government to Fortune 500 experience</p>
                </div>
              </div>
            </div>

            <div className="relative">
              <img
                src={professionalPortrait2}
                alt="Vikas Bhatia Professional"
                className="w-full rounded-2xl shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Expertise Section */}
      <section id="expertise" className="py-24">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="text-center space-y-6 mb-16">
            <h2 className="text-4xl font-sf-pro font-bold text-deep-slate">
              Expertise at the Intersection
            </h2>
            <p className="text-xl text-charcoal/80 max-w-3xl mx-auto leading-relaxed">
              Three critical domains converge to create unprecedented value for modern organizations
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-warm-white border-warm-taupe/30 shadow-lg hover:shadow-xl transition-all duration-300 group">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-sage-green/10 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:bg-sage-green/20 transition-colors">
                  <Shield className="w-8 h-8 text-sage-green" />
                </div>
                <CardTitle className="text-xl font-sf-pro text-deep-slate">Cybersecurity Leadership</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-charcoal/80 text-center">
                  Enterprise-grade security architecture, risk management, and compliance frameworks 
                  for AI-driven organizations.
                </p>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-sage-green" />
                    <span className="text-sm text-charcoal/80">Zero Trust Architecture</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-sage-green" />
                    <span className="text-sm text-charcoal/80">AI Security Frameworks</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-sage-green" />
                    <span className="text-sm text-charcoal/80">Compliance & Governance</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-warm-white border-warm-taupe/30 shadow-lg hover:shadow-xl transition-all duration-300 group">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-copper/10 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:bg-copper/20 transition-colors">
                  <Brain className="w-8 h-8 text-copper" />
                </div>
                <CardTitle className="text-xl font-sf-pro text-deep-slate">AI Innovation</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-charcoal/80 text-center">
                  Strategic AI implementation, product development, and scaling from startup 
                  to enterprise with proven results.
                </p>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-copper" />
                    <span className="text-sm text-charcoal/80">AI Product Strategy</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-copper" />
                    <span className="text-sm text-charcoal/80">Machine Learning Systems</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-copper" />
                    <span className="text-sm text-charcoal/80">AI Governance & Ethics</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-warm-white border-warm-taupe/30 shadow-lg hover:shadow-xl transition-all duration-300 group">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-dusty-blue/10 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:bg-dusty-blue/20 transition-colors">
                  <TrendingUp className="w-8 h-8 text-dusty-blue" />
                </div>
                <CardTitle className="text-xl font-sf-pro text-deep-slate">Business Scaling</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-charcoal/80 text-center">
                  Entrepreneurial expertise in building, funding, and scaling technology companies 
                  from concept to market leadership.
                </p>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-dusty-blue" />
                    <span className="text-sm text-charcoal/80">Startup Strategy</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-dusty-blue" />
                    <span className="text-sm text-charcoal/80">Fundraising & Growth</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-dusty-blue" />
                    <span className="text-sm text-charcoal/80">Market Positioning</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="py-24 bg-cream">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="text-center space-y-6 mb-16">
            <h2 className="text-4xl font-sf-pro font-bold text-deep-slate">
              Proven Track Record
            </h2>
            <p className="text-xl text-charcoal/80 max-w-3xl mx-auto leading-relaxed">
              From government agencies to Fortune 500 enterprises to successful startups
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="bg-warm-white border-warm-taupe/30 shadow-lg hover:shadow-xl transition-all duration-300">
              <CardHeader>
                <div className="flex items-center space-x-3 mb-2">
                  <div className="w-12 h-12 bg-sage-green/10 rounded-xl flex items-center justify-center">
                    <Rocket className="w-6 h-6 text-sage-green" />
                  </div>
                  <div>
                    <CardTitle className="text-lg font-sf-pro text-deep-slate">JustProtect</CardTitle>
                    <CardDescription className="text-charcoal/70">Founder & CEO</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-charcoal/80">
                  Built and scaled AI-powered risk assessment SaaS platform from concept to $700K ARR.
                </p>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-charcoal/70">Funding Raised</span>
                    <span className="text-sm font-medium text-copper">$750K</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-charcoal/70">ARR Achieved</span>
                    <span className="text-sm font-medium text-copper">$700K</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-charcoal/70">Assessments Completed</span>
                    <span className="text-sm font-medium text-copper">5,000+</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-warm-white border-warm-taupe/30 shadow-lg hover:shadow-xl transition-all duration-300">
              <CardHeader>
                <div className="flex items-center space-x-3 mb-2">
                  <div className="w-12 h-12 bg-dusty-blue/10 rounded-xl flex items-center justify-center">
                    <Shield className="w-6 h-6 text-dusty-blue" />
                  </div>
                  <div>
                    <CardTitle className="text-lg font-sf-pro text-deep-slate">National Geospatial-Intelligence Agency</CardTitle>
                    <CardDescription className="text-charcoal/70">Senior Cybersecurity Analyst</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-charcoal/80">
                  Led critical infrastructure protection and advanced threat analysis for national security operations.
                </p>
                <div className="space-y-2">
                  <Badge variant="outline" className="text-xs border-dusty-blue/30 text-dusty-blue">
                    TS/SCI Clearance
                  </Badge>
                  <Badge variant="outline" className="text-xs border-dusty-blue/30 text-dusty-blue">
                    Critical Infrastructure
                  </Badge>
                  <Badge variant="outline" className="text-xs border-dusty-blue/30 text-dusty-blue">
                    Threat Intelligence
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-warm-white border-warm-taupe/30 shadow-lg hover:shadow-xl transition-all duration-300">
              <CardHeader>
                <div className="flex items-center space-x-3 mb-2">
                  <div className="w-12 h-12 bg-copper/10 rounded-xl flex items-center justify-center">
                    <Briefcase className="w-6 h-6 text-copper" />
                  </div>
                  <div>
                    <CardTitle className="text-lg font-sf-pro text-deep-slate">Fortune 500 Consulting</CardTitle>
                    <CardDescription className="text-charcoal/70">Senior Security Consultant</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-charcoal/80">
                  Advised C-suite executives on AI governance, cybersecurity strategy, and digital transformation.
                </p>
                <div className="space-y-2">
                  <Badge variant="outline" className="text-xs border-copper/30 text-copper">
                    Executive Advisory
                  </Badge>
                  <Badge variant="outline" className="text-xs border-copper/30 text-copper">
                    AI Governance
                  </Badge>
                  <Badge variant="outline" className="text-xs border-copper/30 text-copper">
                    Digital Transformation
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-24">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="text-center space-y-6 mb-16">
            <h2 className="text-4xl font-sf-pro font-bold text-deep-slate">
              Strategic Services
            </h2>
            <p className="text-xl text-charcoal/80 max-w-3xl mx-auto leading-relaxed">
              Comprehensive solutions for AI-driven organizations at every stage of growth
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <Card className="bg-warm-white border-warm-taupe/30 shadow-lg hover:shadow-xl transition-all duration-300 group">
              <CardHeader>
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-12 h-12 bg-sage-green/10 rounded-xl flex items-center justify-center group-hover:bg-sage-green/20 transition-colors">
                    <Target className="w-6 h-6 text-sage-green" />
                  </div>
                  <CardTitle className="text-xl font-sf-pro text-deep-slate">Executive Advisory</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-charcoal/80">
                  Strategic guidance for C-suite executives navigating AI adoption, cybersecurity transformation, 
                  and digital innovation initiatives.
                </p>
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-5 h-5 text-sage-green mt-0.5 flex-shrink-0" />
                    <div>
                      <div className="font-medium text-deep-slate">AI Governance Strategy</div>
                      <div className="text-sm text-charcoal/70">Board-ready frameworks and risk management</div>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-5 h-5 text-sage-green mt-0.5 flex-shrink-0" />
                    <div>
                      <div className="font-medium text-deep-slate">Cybersecurity Transformation</div>
                      <div className="text-sm text-charcoal/70">Enterprise security architecture and compliance</div>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-5 h-5 text-sage-green mt-0.5 flex-shrink-0" />
                    <div>
                      <div className="font-medium text-deep-slate">Digital Innovation</div>
                      <div className="text-sm text-charcoal/70">Technology roadmaps and competitive positioning</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-warm-white border-warm-taupe/30 shadow-lg hover:shadow-xl transition-all duration-300 group">
              <CardHeader>
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-12 h-12 bg-copper/10 rounded-xl flex items-center justify-center group-hover:bg-copper/20 transition-colors">
                    <Rocket className="w-6 h-6 text-copper" />
                  </div>
                  <CardTitle className="text-xl font-sf-pro text-deep-slate">Startup Advisory</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-charcoal/80">
                  Hands-on guidance for AI and SaaS startups scaling from concept to market leadership 
                  with proven fundraising and growth strategies.
                </p>
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-5 h-5 text-copper mt-0.5 flex-shrink-0" />
                    <div>
                      <div className="font-medium text-deep-slate">Product-Market Fit</div>
                      <div className="text-sm text-charcoal/70">AI product strategy and market validation</div>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-5 h-5 text-copper mt-0.5 flex-shrink-0" />
                    <div>
                      <div className="font-medium text-deep-slate">Fundraising Strategy</div>
                      <div className="text-sm text-charcoal/70">Investor readiness and pitch optimization</div>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-5 h-5 text-copper mt-0.5 flex-shrink-0" />
                    <div>
                      <div className="font-medium text-deep-slate">Security-First Scaling</div>
                      <div className="text-sm text-charcoal/70">Enterprise readiness and compliance</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-warm-white border-warm-taupe/30 shadow-lg hover:shadow-xl transition-all duration-300 group">
              <CardHeader>
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-12 h-12 bg-dusty-blue/10 rounded-xl flex items-center justify-center group-hover:bg-dusty-blue/20 transition-colors">
                    <Shield className="w-6 h-6 text-dusty-blue" />
                  </div>
                  <CardTitle className="text-xl font-sf-pro text-deep-slate">Security Consulting</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-charcoal/80">
                  Comprehensive cybersecurity assessments, architecture design, and implementation 
                  for AI-powered organizations and critical infrastructure.
                </p>
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-5 h-5 text-dusty-blue mt-0.5 flex-shrink-0" />
                    <div>
                      <div className="font-medium text-deep-slate">AI Security Assessment</div>
                      <div className="text-sm text-charcoal/70">ML model security and data protection</div>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-5 h-5 text-dusty-blue mt-0.5 flex-shrink-0" />
                    <div>
                      <div className="font-medium text-deep-slate">Zero Trust Architecture</div>
                      <div className="text-sm text-charcoal/70">Modern security frameworks and implementation</div>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-5 h-5 text-dusty-blue mt-0.5 flex-shrink-0" />
                    <div>
                      <div className="font-medium text-deep-slate">Compliance & Governance</div>
                      <div className="text-sm text-charcoal/70">SOC2, ISO 27001, and AI standards</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-warm-white border-warm-taupe/30 shadow-lg hover:shadow-xl transition-all duration-300 group">
              <CardHeader>
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-12 h-12 bg-forest/10 rounded-xl flex items-center justify-center group-hover:bg-forest/20 transition-colors">
                    <Users className="w-6 h-6 text-forest" />
                  </div>
                  <CardTitle className="text-xl font-sf-pro text-deep-slate">Board Advisory</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-charcoal/80">
                  Strategic board-level guidance on technology risk, AI governance, and cybersecurity 
                  for high-growth companies and established enterprises.
                </p>
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-5 h-5 text-forest mt-0.5 flex-shrink-0" />
                    <div>
                      <div className="font-medium text-deep-slate">Technology Risk Oversight</div>
                      <div className="text-sm text-charcoal/70">Board reporting and risk management</div>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-5 h-5 text-forest mt-0.5 flex-shrink-0" />
                    <div>
                      <div className="font-medium text-deep-slate">AI Ethics & Governance</div>
                      <div className="text-sm text-charcoal/70">Responsible AI frameworks and policies</div>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-5 h-5 text-forest mt-0.5 flex-shrink-0" />
                    <div>
                      <div className="font-medium text-deep-slate">Strategic Planning</div>
                      <div className="text-sm text-charcoal/70">Technology roadmaps and competitive analysis</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Credentials Section */}
      <section className="py-24 bg-cream">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="text-center space-y-6 mb-16">
            <h2 className="text-4xl font-sf-pro font-bold text-deep-slate">
              Credentials & Recognition
            </h2>
            <p className="text-xl text-charcoal/80 max-w-3xl mx-auto leading-relaxed">
              Professional certifications and security clearances that validate expertise
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="bg-warm-white border-warm-taupe/30 shadow-lg text-center p-6">
              <div className="w-16 h-16 bg-sage-green/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-sage-green" />
              </div>
              <h3 className="font-sf-pro font-semibold text-deep-slate mb-2">TS/SCI Clearance</h3>
              <p className="text-sm text-charcoal/70">Top Secret/Sensitive Compartmented Information</p>
            </Card>

            <Card className="bg-warm-white border-warm-taupe/30 shadow-lg text-center p-6">
              <div className="w-16 h-16 bg-copper/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Award className="w-8 h-8 text-copper" />
              </div>
              <h3 className="font-sf-pro font-semibold text-deep-slate mb-2">CISSP</h3>
              <p className="text-sm text-charcoal/70">Certified Information Systems Security Professional</p>
            </Card>

            <Card className="bg-warm-white border-warm-taupe/30 shadow-lg text-center p-6">
              <div className="w-16 h-16 bg-dusty-blue/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Brain className="w-8 h-8 text-dusty-blue" />
              </div>
              <h3 className="font-sf-pro font-semibold text-deep-slate mb-2">AI Standards</h3>
              <p className="text-sm text-charcoal/70">ISO 42001 & NIST AI.600-1 Expertise</p>
            </Card>

            <Card className="bg-warm-white border-warm-taupe/30 shadow-lg text-center p-6">
              <div className="w-16 h-16 bg-forest/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Zap className="w-8 h-8 text-forest" />
              </div>
              <h3 className="font-sf-pro font-semibold text-deep-slate mb-2">Startup Success</h3>
              <p className="text-sm text-charcoal/70">$750K Raised, $700K ARR Achieved</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24">
        <div className="max-w-4xl mx-auto px-6 lg:px-12 text-center">
          <div className="space-y-8">
            <div className="space-y-6">
              <h2 className="text-4xl font-sf-pro font-bold text-deep-slate">
                Ready to Transform Your Organization?
              </h2>
              <p className="text-xl text-charcoal/80 leading-relaxed max-w-2xl mx-auto">
                Let's discuss how AI-cybersecurity expertise can accelerate your growth, 
                secure your innovation, and position you for market leadership.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
              <a
                href="mailto:vikas@vikasbhatia.com"
                className="flex items-center space-x-3 bg-sage-green hover:bg-sage-green/90 text-warm-white px-8 py-4 rounded-lg font-medium transition-all duration-200 hover:shadow-lg"
              >
                <Mail className="w-5 h-5" />
                <span>vikas@vikasbhatia.com</span>
              </a>
              <a
                href="https://linkedin.com/in/vikasbhatia"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center space-x-3 border border-deep-slate text-deep-slate hover:bg-warm-taupe/20 px-8 py-4 rounded-lg font-medium transition-all duration-200"
              >
                <Linkedin className="w-5 h-5" />
                <span>Connect on LinkedIn</span>
              </a>
            </div>

            <div className="pt-8 border-t border-warm-taupe/30">
              <p className="text-sm text-charcoal/70">
                Available for executive advisory, board positions, and strategic consulting engagements
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-deep-slate text-warm-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="text-center space-y-4">
            <div className="font-sf-pro text-xl font-semibold">Vikas Bhatia</div>
            <p className="text-warm-white/80">AI-Cybersecurity Executive | Bridging Innovation and Risk Management</p>
            <div className="flex justify-center space-x-6 pt-4">
              <a
                href="mailto:vikas@vikasbhatia.com"
                className="text-warm-white/80 hover:text-warm-white transition-colors"
              >
                <Mail className="w-5 h-5" />
              </a>
              <a
                href="https://linkedin.com/in/vikasbhatia"
                target="_blank"
                rel="noopener noreferrer"
                className="text-warm-white/80 hover:text-warm-white transition-colors"
              >
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
            <div className="pt-8 border-t border-warm-white/20">
              <p className="text-sm text-warm-white/60">
                © 2024 Vikas Bhatia. All rights reserved.
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

