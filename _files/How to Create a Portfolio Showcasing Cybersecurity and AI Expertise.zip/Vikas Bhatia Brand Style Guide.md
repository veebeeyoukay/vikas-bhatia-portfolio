# Vikas Bhatia Brand Style Guide
## Inspired by Jony Ive's Design Philosophy

---

## Design Philosophy

### Core Principles (Based on Jony Ive's Approach)

#### 1. Minimalism and Simplicity
*"The less, the better"*
- Remove all unnecessary elements
- Focus on essential functionality
- Create space for user intuition and engagement
- Achieve "profound and enduring beauty in simplicity"

#### 2. Useful and Functional
*"There is beauty when something works and it works intuitively"*
- Every element must serve a clear purpose
- Prioritize user experience and accessibility
- Design for quick accessibility and multitasking
- Create coherent systems that guide users naturally

#### 3. Understandable
*"Good design is primarily about clearly defined functionality and structure"*
- Establish clear hierarchy and order
- Make complexity understandable through intuition
- Prioritize user-centric design
- Guide users without direct instruction

#### 4. Unobtrusive
*"Neutral and integrated with the environment"*
- Design should be inviting yet neutral
- Leave room for user self-expression
- Influence users in a subtle, natural way
- Integrate seamlessly with surroundings

#### 5. Thorough in Every Detail
*"Complete accuracy in every inch"*
- Meticulous attention to all design elements
- Perfect execution at every scale
- Consistent quality across all touchpoints
- Craftsmanship in the smallest details

---

## Chromatic Color System

### Primary Color Palette
*Sophisticated, muted tones with high contrast*

#### Core Colors
- **Deep Slate**: `#0f1b27` - Primary dark, sophisticated base
- **Warm White**: `#f8f6f3` - Clean, premium background
- **Sage Green**: `#557373` - Calming, professional accent
- **Warm Taupe**: `#d9c4a9` - Elegant, neutral support
- **Charcoal**: `#2c2c2c` - Strong contrast for text

#### Accent Colors
- **Copper**: `#bf835f` - Warm, premium highlight
- **Dusty Blue**: `#819fa7` - Subtle, sophisticated accent
- **Cream**: `#f2efea` - Soft, luxurious background
- **Forest**: `#314021` - Deep, grounding accent
- **Blush**: `#d9b6a3` - Warm, approachable highlight

### Color Usage Guidelines

#### Hierarchy
1. **Primary**: Deep Slate for main text and key elements
2. **Secondary**: Sage Green for interactive elements and accents
3. **Tertiary**: Copper for highlights and call-to-action elements
4. **Background**: Warm White and Cream for clean spaces
5. **Support**: Warm Taupe for subtle divisions and secondary text

#### Contrast Ratios
- **Text on Light Backgrounds**: Minimum 7:1 (AAA compliance)
- **Text on Dark Backgrounds**: Minimum 7:1 (AAA compliance)
- **Interactive Elements**: Minimum 4.5:1 (AA compliance)

#### Color Psychology
- **Deep Slate**: Authority, sophistication, trust
- **Sage Green**: Growth, balance, innovation
- **Copper**: Warmth, premium quality, craftsmanship
- **Warm White**: Purity, clarity, minimalism
- **Warm Taupe**: Elegance, timelessness, stability

---

## Typography System

### Font Hierarchy
*Clean, readable, sophisticated typefaces*

#### Primary Typeface: Inter
- **Usage**: Headlines, body text, UI elements
- **Characteristics**: Modern, highly legible, neutral
- **Weights**: Light (300), Regular (400), Medium (500), SemiBold (600), Bold (700)

#### Secondary Typeface: SF Pro Display (Apple System Font)
- **Usage**: Special headings, brand elements
- **Characteristics**: Apple-inspired, clean, sophisticated
- **Weights**: Regular (400), Medium (500), SemiBold (600), Bold (700)

### Type Scale
*Harmonious proportions based on 1.25 ratio*

#### Desktop Scale
- **H1**: 48px / 3rem - Hero headlines
- **H2**: 38px / 2.375rem - Section headers
- **H3**: 30px / 1.875rem - Subsection headers
- **H4**: 24px / 1.5rem - Card titles
- **H5**: 20px / 1.25rem - Small headers
- **H6**: 16px / 1rem - Captions
- **Body Large**: 18px / 1.125rem - Primary body text
- **Body**: 16px / 1rem - Standard body text
- **Body Small**: 14px / 0.875rem - Secondary text
- **Caption**: 12px / 0.75rem - Fine print

#### Mobile Scale
- **H1**: 36px / 2.25rem
- **H2**: 30px / 1.875rem
- **H3**: 24px / 1.5rem
- **H4**: 20px / 1.25rem
- **H5**: 18px / 1.125rem
- **H6**: 16px / 1rem
- **Body Large**: 16px / 1rem
- **Body**: 14px / 0.875rem
- **Body Small**: 12px / 0.75rem
- **Caption**: 11px / 0.6875rem

### Typography Guidelines
- **Line Height**: 1.5 for body text, 1.2 for headlines
- **Letter Spacing**: -0.02em for large text, 0 for body text
- **Paragraph Spacing**: 1.5rem between paragraphs
- **Maximum Line Length**: 65-75 characters for optimal readability

---

## Spacing System

### Base Unit: 8px
*Consistent, mathematical spacing for harmony*

#### Spacing Scale
- **xs**: 4px (0.25rem) - Tight spacing
- **sm**: 8px (0.5rem) - Small spacing
- **md**: 16px (1rem) - Medium spacing
- **lg**: 24px (1.5rem) - Large spacing
- **xl**: 32px (2rem) - Extra large spacing
- **2xl**: 48px (3rem) - Section spacing
- **3xl**: 64px (4rem) - Major section spacing
- **4xl**: 96px (6rem) - Hero spacing

#### Component Spacing
- **Button Padding**: 12px 24px (vertical, horizontal)
- **Card Padding**: 24px
- **Section Padding**: 64px (desktop), 32px (mobile)
- **Container Max Width**: 1200px
- **Grid Gutters**: 24px

---

## Layout System

### Grid Structure
*Clean, organized, Apple-inspired layouts*

#### Desktop Grid
- **Columns**: 12-column grid
- **Container**: 1200px max-width
- **Gutters**: 24px
- **Margins**: 48px (large screens), 24px (medium screens)

#### Mobile Grid
- **Columns**: 4-column grid
- **Container**: 100% width
- **Gutters**: 16px
- **Margins**: 16px

### Layout Principles
1. **Generous White Space**: Allow content to breathe
2. **Clear Hierarchy**: Visual importance through size and spacing
3. **Alignment**: Everything aligns to the grid
4. **Balance**: Asymmetrical balance for visual interest
5. **Focus**: One primary focal point per section

---

## Component Library

### Buttons
*Clean, purposeful, sophisticated*

#### Primary Button
- **Background**: Sage Green (`#557373`)
- **Text**: Warm White (`#f8f6f3`)
- **Padding**: 12px 24px
- **Border Radius**: 8px
- **Font Weight**: Medium (500)
- **Hover**: Darken background by 10%
- **Focus**: 2px outline in Copper (`#bf835f`)

#### Secondary Button
- **Background**: Transparent
- **Text**: Deep Slate (`#0f1b27`)
- **Border**: 1px solid Deep Slate
- **Padding**: 12px 24px
- **Border Radius**: 8px
- **Font Weight**: Medium (500)
- **Hover**: Background Warm Taupe (`#d9c4a9`)

#### Tertiary Button
- **Background**: Transparent
- **Text**: Sage Green (`#557373`)
- **Padding**: 8px 16px
- **Font Weight**: Medium (500)
- **Hover**: Underline
- **Focus**: 2px outline in Copper

### Cards
*Minimal, elegant containers*

#### Standard Card
- **Background**: Warm White (`#f8f6f3`)
- **Border**: None
- **Border Radius**: 12px
- **Shadow**: 0 4px 24px rgba(15, 27, 39, 0.08)
- **Padding**: 24px
- **Hover**: Lift with increased shadow

#### Featured Card
- **Background**: Cream (`#f2efea`)
- **Border**: 1px solid Warm Taupe (`#d9c4a9`)
- **Border Radius**: 12px
- **Shadow**: 0 8px 32px rgba(15, 27, 39, 0.12)
- **Padding**: 32px

### Navigation
*Clean, unobtrusive, functional*

#### Header Navigation
- **Background**: Warm White with 95% opacity
- **Backdrop Blur**: 8px
- **Height**: 64px
- **Padding**: 0 48px
- **Border Bottom**: 1px solid rgba(217, 196, 169, 0.3)
- **Sticky**: Yes

#### Navigation Links
- **Font**: Inter Medium
- **Size**: 16px
- **Color**: Deep Slate (`#0f1b27`)
- **Hover**: Sage Green (`#557373`)
- **Active**: Copper (`#bf835f`)
- **Spacing**: 32px between links

### Forms
*Intuitive, accessible, elegant*

#### Input Fields
- **Background**: Warm White (`#f8f6f3`)
- **Border**: 1px solid Warm Taupe (`#d9c4a9`)
- **Border Radius**: 8px
- **Padding**: 12px 16px
- **Font**: Inter Regular, 16px
- **Focus**: Border color Sage Green, 2px outline Copper
- **Error**: Border color error red, helper text in error color

#### Labels
- **Font**: Inter Medium, 14px
- **Color**: Deep Slate (`#0f1b27`)
- **Margin Bottom**: 8px

---

## Iconography

### Icon Style
*Minimal, consistent, purposeful*

#### Characteristics
- **Style**: Outline icons with 1.5px stroke
- **Size**: 16px, 20px, 24px, 32px
- **Color**: Inherits from parent or Deep Slate
- **Corner Radius**: 2px for rectangular elements
- **Grid**: 24x24px base grid

#### Icon Library
- **Lucide Icons**: Primary icon set
- **Custom Icons**: When Lucide doesn't provide suitable options
- **Consistency**: All icons follow same visual weight and style

### Usage Guidelines
- **Functional**: Icons should enhance understanding, not decorate
- **Recognizable**: Use familiar, universal symbols
- **Consistent**: Same icon for same function across all touchpoints
- **Accessible**: Include alt text and don't rely solely on icons for meaning

---

## Motion and Animation

### Animation Principles
*Subtle, purposeful, Apple-inspired*

#### Timing Functions
- **Ease Out**: `cubic-bezier(0.25, 0.46, 0.45, 0.94)` - Default
- **Ease In Out**: `cubic-bezier(0.645, 0.045, 0.355, 1)` - Smooth transitions
- **Spring**: `cubic-bezier(0.175, 0.885, 0.32, 1.275)` - Playful interactions

#### Duration Guidelines
- **Micro Interactions**: 150-200ms
- **Component Transitions**: 250-300ms
- **Page Transitions**: 400-500ms
- **Loading States**: 800-1200ms

#### Animation Types
1. **Hover Effects**: Subtle color changes, gentle lifts
2. **Focus States**: Smooth outline appearances
3. **Loading States**: Elegant progress indicators
4. **Page Transitions**: Smooth, directional movements
5. **Scroll Animations**: Gentle fade-ins and parallax

### Motion Guidelines
- **Purposeful**: Every animation should have a clear purpose
- **Subtle**: Animations should enhance, not distract
- **Consistent**: Same timing and easing across similar interactions
- **Accessible**: Respect user preferences for reduced motion

---

## Imagery Guidelines

### Photography Style
*Clean, professional, sophisticated*

#### Characteristics
- **Style**: Clean, minimal, professional
- **Lighting**: Natural, soft lighting preferred
- **Composition**: Generous white space, clear focal points
- **Color Grading**: Slightly desaturated, warm tones
- **Quality**: High resolution, crisp, professional

#### Usage Guidelines
- **Hero Images**: Large, impactful, minimal text overlay
- **Portrait Photos**: Professional, approachable, high-quality
- **Background Images**: Subtle, don't compete with text
- **Icons and Graphics**: Minimal, purposeful, consistent style

### Image Treatment
- **Border Radius**: 8px for small images, 12px for large images
- **Aspect Ratios**: 16:9 for hero, 4:3 for cards, 1:1 for avatars
- **Filters**: Subtle desaturation and warm color grading
- **Overlays**: Dark overlay (40% opacity) for text readability

---

## Accessibility Standards

### WCAG 2.1 AA Compliance
*Inclusive design for all users*

#### Color Accessibility
- **Contrast Ratios**: Minimum 4.5:1 for normal text, 7:1 for enhanced
- **Color Independence**: Never rely solely on color to convey information
- **Color Blindness**: Test with color blindness simulators

#### Typography Accessibility
- **Font Size**: Minimum 16px for body text
- **Line Height**: Minimum 1.5 for body text
- **Font Weight**: Minimum 400 for body text
- **Zoom**: Support up to 200% zoom without horizontal scrolling

#### Interaction Accessibility
- **Focus Indicators**: Clear, visible focus states
- **Touch Targets**: Minimum 44px for interactive elements
- **Keyboard Navigation**: Full keyboard accessibility
- **Screen Readers**: Proper semantic markup and ARIA labels

#### Motion Accessibility
- **Reduced Motion**: Respect prefers-reduced-motion setting
- **Autoplay**: No auto-playing videos or animations
- **Seizure Prevention**: No flashing content above 3Hz

---

## Brand Voice and Tone

### Voice Characteristics
*Professional, approachable, sophisticated*

#### Core Attributes
- **Authoritative**: Confident expertise without arrogance
- **Innovative**: Forward-thinking and cutting-edge
- **Trustworthy**: Reliable and dependable
- **Sophisticated**: Refined and professional
- **Approachable**: Accessible and human

#### Tone Variations
- **Executive Presentations**: Formal, authoritative, strategic
- **Startup Communications**: Energetic, innovative, growth-focused
- **Technical Content**: Precise, detailed, educational
- **Marketing Materials**: Confident, compelling, benefit-focused
- **Social Media**: Professional yet personable, thought-leadership

---

## Implementation Guidelines

### Development Standards
*Clean, maintainable, scalable code*

#### CSS Architecture
- **Methodology**: Utility-first with Tailwind CSS
- **Custom Properties**: CSS variables for colors and spacing
- **Responsive Design**: Mobile-first approach
- **Performance**: Optimized for fast loading

#### Component Structure
- **Reusable**: Build once, use everywhere
- **Modular**: Independent, composable components
- **Accessible**: Built-in accessibility features
- **Documented**: Clear usage guidelines and examples

### Quality Assurance
- **Cross-browser Testing**: Chrome, Firefox, Safari, Edge
- **Device Testing**: Desktop, tablet, mobile
- **Accessibility Testing**: Screen readers, keyboard navigation
- **Performance Testing**: Page speed, Core Web Vitals

---

## Usage Examples

### Color Combinations
*Sophisticated, harmonious pairings*

#### Primary Combinations
1. **Deep Slate + Warm White**: High contrast, professional
2. **Sage Green + Cream**: Calming, sophisticated
3. **Copper + Warm Taupe**: Warm, premium
4. **Dusty Blue + Warm White**: Clean, trustworthy
5. **Forest + Blush**: Natural, approachable

#### Background Combinations
1. **Warm White background + Deep Slate text**
2. **Cream background + Charcoal text**
3. **Deep Slate background + Warm White text**
4. **Sage Green background + Warm White text**

### Typography Pairings
*Harmonious, readable combinations*

#### Heading + Body Combinations
1. **SF Pro Display Bold + Inter Regular**: Apple-inspired elegance
2. **Inter SemiBold + Inter Regular**: Consistent, clean
3. **SF Pro Display Medium + Inter Light**: Sophisticated contrast

---

## Conclusion

This style guide embodies Jony Ive's design philosophy of minimalism, functionality, and meticulous attention to detail. The chromatic color system provides sophistication while maintaining accessibility and usability. Every element is designed to work harmoniously together, creating a cohesive, premium brand experience that reflects Vikas Bhatia's position as an AI-Cybersecurity Executive.

The system is built to be:
- **Scalable**: Works across all touchpoints and platforms
- **Accessible**: Meets WCAG 2.1 AA standards
- **Maintainable**: Clear guidelines for consistent implementation
- **Sophisticated**: Reflects premium positioning and expertise
- **Functional**: Every element serves a clear purpose

*"What we make stands testament to who we are."* - Jony Ive

